# 에버그린 장로교회 - 정적 웹사이트

이 폴더에는 GitHub Pages에서 호스팅할 수 있는 에버그린 장로교회의 정적 HTML 웹사이트가 포함되어 있습니다.

## 폴더 구조

```
atlegchurch-static/
├── index.html                 # 홈페이지
├── styles.css                 # 모든 페이지의 스타일
├── README.md                  # 이 파일
├── images/                    # 모든 이미지 파일
│   ├── pastor.png
│   ├── welcome.jpg
│   ├── newcomers.jpg
│   ├── worship.jpg
│   └── korean-school.jpg
├── church-intro/              # 교회소개
│   └── index.html
├── newcomers/                 # 새가족안내
│   └── index.html
├── worship-guide/             # 예배안내
│   └── index.html
├── serving-people/            # 섬기는사람들
├── church-history/            # 교회역사
├── church-vision/             # 교회비전
├── action-goals/              # 실천목표
├── evergreen-tv/              # 에버그린TV
├── member-registration/       # 교인등록안내
├── discipleship/              # 양육/훈련과정
├── directions/                # 교회오시는길
├── next-generation/           # 다음세대
├── km-youth/                  # KM청년부
├── korean-school/             # 한국학교
├── service-mission/           # 섬김과선교
├── district-meetings/         # 구역모임
├── missionary-work/           # 선교사역
├── core-ministry/             # 핵심사역
├── bible-school/              # 통성경학교
├── fellowship/                # 성도의교제
├── church-news/               # 교회소식
├── bulletin/                  # 교회주보
└── album/                     # 에버그린앨범
```

## GitHub Pages에 배포하기

### 1단계: GitHub 저장소 생성
- https://github.com/new에서 새 저장소 생성
- 저장소 이름: `atlegchurch` (원하는 이름 사용 가능)
- 설정: Public으로 설정

### 2단계: 파일 업로드
```bash
# 저장소 클론
git clone https://github.com/yourname/atlegchurch.git
cd atlegchurch

# 현재 파일들을 저장소에 복사
cp -r /path/to/atlegchurch-static/* .

# 변경사항 커밋
git add .
git commit -m "Initial website upload"
git push origin main
```

### 3단계: GitHub Pages 활성화
1. GitHub의 저장소 설정 (Settings)으로 이동
2. 좌측 메뉴에서 "Pages" 선택
3. Source를 "main" branch로 설정
4. Save 클릭

약 1-2분 후 웹사이트가 다음 URL에서 활성화됩니다:
```
https://yourname.github.io/atlegchurch
```

## 페이지 편집 방법

### 텍스트 수정하기
각 HTML 파일을 텍스트 에디터에서 열고 내용을 수정할 수 있습니다.

예시:
- `index.html` - 홈페이지 내용
- `church-intro/index.html` - 교회소개 페이지
- `newcomers/index.html` - 새가족안내 페이지

### 이미지 추가하기
1. 새 이미지를 `images/` 폴더에 추가
2. HTML 파일에서 다음과 같이 사용:
```html
<img src="../images/filename.jpg" alt="설명">
```

### 새 페이지 만들기
1. 새 폴더 생성 (예: `my-new-page/`)
2. 폴더 안에 `index.html` 생성
3. 기존 페이지의 HTML을 복사하고 내용만 수정
4. 네비게이션에 링크 추가

예시:
```html
<li><a href="../my-new-page/">새 페이지</a></li>
```

## 수정 후 배포하기

변경사항을 적용하려면:

```bash
# 변경된 파일 스테이징
git add .

# 커밋
git commit -m "업데이트 설명"

# 푸시 (GitHub에 업로드)
git push origin main
```

약 1-2분 후 웹사이트에 변경사항이 반영됩니다.

## 현재 포함된 페이지

- ✅ **홈페이지** (index.html)
- ✅ **교회소개 - 환영인사** (church-intro/index.html)
- ✅ **새가족안내** (newcomers/index.html)
- ✅ **예배안내** (worship-guide/index.html)
- ⏳ 다른 페이지들 (placeholder 준비 완료)

## 다음 단계

다음 페이지들을 추가로 제작할 수 있습니다:
- 섬기는사람들
- 교회역사
- 교회비전
- 실천목표
- 에버그린TV (유튜브 영상 임베드)
- 기타 하위 페이지들

## CSS 스타일링

모든 페이지는 `styles.css`에서 스타일을 가져옵니다. 전체 디자인을 변경하려면 이 파일을 수정하면 됩니다.

주요 색상:
- 주색: #F4F0E9
- 글자색: #333
- 강조색: #2c3e50

## 문제 해결

### 링크가 작동하지 않음
- 상대 경로 확인: `../` 사용하여 상위 디렉토리로 이동

### 이미지가 보이지 않음
- 이미지 파일이 `images/` 폴더에 있는지 확인
- 파일명 스펠링 확인

### 스타일이 적용되지 않음
- CSS 파일 경로 확인
- 브라우저 캐시 지우기

## 문의

사이트 수정에 관한 문의는 Claude에게 요청하면 됩니다.

---

**Created:** 2026-06-27
**Last Updated:** 2026-06-27
